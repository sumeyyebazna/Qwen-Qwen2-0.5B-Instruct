#!/usr/bin/env bash
set -e

python -V
pip -q install --upgrade pip

# torchao bazen transformers içinde otomatik import ile uyumsuzluk çıkarabiliyor.
pip -q uninstall -y torchao || true

# Temiz kurulum
pip -q install -r requirements.txt

python - <<'PY'
import torch, numpy
print("numpy:", numpy.__version__)
print("torch:", torch.__version__)
print("CUDA:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
PY
