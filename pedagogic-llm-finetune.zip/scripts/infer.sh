#!/usr/bin/env bash
set -e
python src/infer.py
