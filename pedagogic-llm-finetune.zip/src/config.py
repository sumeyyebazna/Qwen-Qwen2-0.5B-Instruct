from dataclasses import dataclass

@dataclass
class TrainConfig:
    # Küçük model: Colab T4'te stabil şekilde eğitilebilir.
    model_name: str = "Qwen/Qwen2-0.5B-Instruct"
    max_len: int = 256

    # Eğitim hiperparametreleri (FP32 stabil)
    lr: float = 2e-5
    weight_decay: float = 0.01
    micro_batch: int = 1
    grad_accum: int = 8
    max_steps: int = 80
    log_every: int = 10
    clip: float = 1.0

    # Dosyalar
    train_path: str = "data/mega_dataset_alpaca_train.jsonl"
    val_path: str   = "data/mega_dataset_alpaca_val.jsonl"
    out_dir: str = "outputs"
