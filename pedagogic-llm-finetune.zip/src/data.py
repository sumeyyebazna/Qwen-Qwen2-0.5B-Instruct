from datasets import load_dataset
from typing import Dict

PROMPT_TMPL = """### Görev:
{instruction}

### Girdi:
{input}

### Yanıt:
{output}"""

def build_text(example: Dict) -> Dict:
    instruction = (example.get("instruction") or "").strip()
    _input      = (example.get("input") or "").strip()
    output      = (example.get("output") or "").strip()
    text = PROMPT_TMPL.format(instruction=instruction, input=_input, output=output)
    return {"text": text}

def load_alpaca_jsonl(train_path: str, val_path: str):
    ds_train = load_dataset("json", data_files=train_path, split="train")
    ds_val   = load_dataset("json", data_files=val_path, split="train")
    return ds_train, ds_val

def tokenize_dataset(ds, tokenizer, max_len: int):
    def tok(batch):
        return tokenizer(
            batch["text"],
            truncation=True,
            max_length=max_len,
            padding="max_length",
        )
    # remove all columns after tokenization
    tok_ds = ds.map(tok, batched=True, remove_columns=ds.column_names)
    return tok_ds
