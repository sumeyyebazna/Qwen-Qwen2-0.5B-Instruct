import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

MODEL_DIR = "outputs/finetuned"

PROMPT = """### Görev:
Öğrenci cevabını değerlendir ve doğru yaklaşımı öğret.

### Girdi:
[Lecture 6 | Q8]
Soru: Foundation modellerin temel sınırlamaları (limitations) nelerdir?
Öğrenci Cevabı: Aslında hiçbir dezavantajı yoktur.
Değerlendir ve öğret.

### Yanıt:
Tek seferde cevap ver. Format: ❌ Yanlış. Hata tipi: ... Doğrusu: ..."""

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR, use_fast=True)
    model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, torch_dtype=torch.float32).to(device)
    model.eval()

    inputs = tokenizer(PROMPT, return_tensors="pt").to(device)

    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=160,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
        )

    text = tokenizer.decode(out[0], skip_special_tokens=True)
    print("\n=== MODEL ÇIKTISI (Sadece yeni üretilen) ===\n")
    print(text[len(PROMPT):].strip())

if __name__ == "__main__":
    main()
