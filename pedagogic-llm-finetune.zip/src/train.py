import os
import torch
from torch.optim import AdamW
from transformers import AutoTokenizer, AutoModelForCausalLM
from transformers.data.data_collator import default_data_collator
from tqdm.auto import tqdm

from config import TrainConfig
from data import load_alpaca_jsonl, build_text, tokenize_dataset
from utils import set_seed, ensure_dir, gpu_mem_gb

def main():
    cfg = TrainConfig()
    set_seed(42)
    ensure_dir(cfg.out_dir)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device)

    tokenizer = AutoTokenizer.from_pretrained(cfg.model_name, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # FP32: NaN/Inf riskini ciddi azaltır, T4'te daha stabil.
    model = AutoModelForCausalLM.from_pretrained(
        cfg.model_name,
        torch_dtype=torch.float32,
    ).to(device)

    model.train()
    model.gradient_checkpointing_enable()  # bellek azaltır
    model.config.use_cache = False         # training için kapat

    # Dataset
    train_ds, val_ds = load_alpaca_jsonl(cfg.train_path, cfg.val_path)
    print("train rows:", len(train_ds), "val rows:", len(val_ds))

    train_txt = train_ds.map(build_text)
    val_txt   = val_ds.map(build_text)

    train_tok = tokenize_dataset(train_txt, tokenizer, cfg.max_len)
    val_tok   = tokenize_dataset(val_txt, tokenizer, cfg.max_len)

    train_loader = torch.utils.data.DataLoader(
        train_tok, batch_size=cfg.micro_batch, shuffle=True, collate_fn=default_data_collator
    )

    opt = AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)

    step = 0
    running = 0.0
    opt.zero_grad(set_to_none=True)

    pbar = tqdm(total=cfg.max_steps, desc="train")

    for batch in train_loader:
        step += 1
        batch = {k: v.to(device) for k, v in batch.items()}
        batch["labels"] = batch["input_ids"].clone()

        outputs = model(**batch)
        loss = outputs.loss / cfg.grad_accum

        # NaN/Inf guard
        if not torch.isfinite(loss):
            print(f"🚨 NaN/Inf yakalandı step={step}. Durduruldu.")
            break

        loss.backward()
        running += loss.item()

        if step % cfg.grad_accum == 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.clip)
            opt.step()
            opt.zero_grad(set_to_none=True)

        if step % cfg.log_every == 0:
            mem = gpu_mem_gb()
            avg_loss = (running * cfg.grad_accum) / cfg.log_every
            if mem is not None:
                print(f"step {step}/{cfg.max_steps} | loss {avg_loss:.4f} | memGB {mem:.2f}")
            else:
                print(f"step {step}/{cfg.max_steps} | loss {avg_loss:.4f}")
            running = 0.0

        if torch.cuda.is_available() and step % 20 == 0:
            torch.cuda.empty_cache()

        pbar.update(1)
        if step >= cfg.max_steps:
            break

    pbar.close()

    # Save
    save_path = os.path.join(cfg.out_dir, "finetuned")
    ensure_dir(save_path)
    model.save_pretrained(save_path)
    tokenizer.save_pretrained(save_path)
    print("✅ Model kaydedildi:", save_path)

if __name__ == "__main__":
    main()
